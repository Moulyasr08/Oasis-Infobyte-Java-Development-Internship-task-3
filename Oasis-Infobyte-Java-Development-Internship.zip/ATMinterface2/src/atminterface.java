import java.util.Scanner;

public class atminterface {
	public static void main(String[] args) {
        float balance = 100000f;
        int withdraw, deposit;
        String transactionhistory = "";
        int accountno = 123456789;
        int password = 123;
        Scanner sc = new Scanner(System.in);
        int chance = 1;

        while (chance <= 3) {
            System.out.println("Enter the AccountNo:");
            int uname = sc.nextInt();
            System.out.println("Enter the password:");
            int pass = sc.nextInt();

            if (uname == accountno && pass == password) {
                System.out.println("Success! You can proceed with further operations.");
                break;
            } else {
                System.out.println("Wrong AccountNo and password.");
                if (chance == 3) {
                    System.out.println("Maximum login attempts reached. Exiting...");
                    System.exit(0);
                }
                chance++;
                System.out.println("You have " + (4 - chance) + " more chances.");
            }
        }

        while (true) {
            System.out.println("Welcome to Simplified Learner ATM");

            System.out.println("Choose 1 for withdraw:");
            System.out.println("Choose 2 for Deposit:");
            System.out.println("Choose 3 for Check Balance:");
            System.out.println("Choose 4 for Transaction History:");
            System.out.println("Choose 5 for EXIT");

            System.out.print("Choose the operation you want to perform: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the amount to be withdrawn: ");
                    withdraw = sc.nextInt();

                    if (balance >= withdraw) {
                        balance = balance - withdraw;
                        System.out.println("Please collect your money.");
                        String str = withdraw + " RS withdrawn";
                        transactionhistory = transactionhistory.concat(str);
                    } else {
                        System.out.println("Insufficient Balance");
                    }
                    System.out.println("");
                    break;
                case 2:
                    System.out.print("Enter the amount to be deposited: ");
                    deposit = sc.nextInt();
                    balance = balance + deposit;
                    System.out.println("Your money has been successfully deposited.");
                    String str = deposit + " RS deposited";
                    transactionhistory = transactionhistory.concat(str);
                    System.out.println("");
                    break;
                case 3:
                    System.out.println("Balance: " + balance);
                    System.out.println("");
                    break;
                case 4:
                    System.out.println("Transaction History:");
                    System.out.println(transactionhistory);
                    break;
                case 5:
                    System.exit(0);
            }
        }
    }
}


